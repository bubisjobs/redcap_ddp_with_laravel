<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateHaematologyddpsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('haematologyddps', function(Blueprint $table)
		{
			$table->integer('requestid')->nullable();
			$table->string('serial', 14);
			$table->string('diagnosis', 50)->nullable();
			$table->string('projectid', 9);
			$table->string('doctor', 15)->nullable();
			$table->dateTime('dateofrequest');
			$table->string('specimencollectedby', 15)->nullable();
			$table->dateTime('collectiondate')->nullable();
			$table->char('collectiontime', 5)->nullable();
			$table->float('hb', 53, 0)->nullable();
			$table->float('wbc', 53, 0)->nullable();
			$table->float('neutro', 53, 0)->nullable();
			$table->float('lympho', 53, 0)->nullable();
			$table->float('mono', 53, 0)->nullable();
			$table->float('eos', 53, 0)->nullable();
			$table->float('baso', 53, 0)->nullable();
			$table->float('rbc', 53, 0)->nullable();
			$table->float('pcv', 53, 0)->nullable();
			$table->float('mvc', 53, 0)->nullable();
			$table->float('mchc', 53, 0)->nullable();
			$table->string('thickbloodfilm', 50)->nullable();
			$table->float('plats', 53, 0)->nullable();
			$table->string('bloodgrp', 50)->nullable();
			$table->string('retics', 50)->nullable();
			$table->float('neutroabsolute', 53, 0)->nullable();
			$table->float('lymphoabsolute', 53, 0)->nullable();
			$table->float('monoabsolute', 53, 0)->nullable();
			$table->float('esoabsolute', 53, 0)->nullable();
			$table->float('basoabsolute', 53, 0)->nullable();
			$table->float('esr', 53, 0)->nullable();
			$table->float('rdw', 53, 0)->nullable();
			$table->string('sickle', 50)->nullable();
			$table->string('hbgenot', 50)->nullable();
			$table->float('pt', 53, 0)->nullable();
			$table->float('inr', 53, 0)->nullable();
			$table->float('aptt', 53, 0)->nullable();
			$table->string('filmcomment', 1000)->nullable();
			$table->string('comments', 200)->nullable();
			$table->string('meta')->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('haematologyddps');
	}

}
