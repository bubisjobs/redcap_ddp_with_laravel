<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateLabReqHaematologyTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('LabReqHaematology', function(Blueprint $table)
		{
			$table->integer('RequestID', true);
			$table->char('PatientID', 9);
			$table->smallInteger('PatientType')->nullable();
			$table->smallInteger('Location');
			$table->string('ChargeCode', 50);
			$table->smallInteger('Doctor')->nullable();
			$table->dateTime('RequestDate');
			$table->time('RequestTime');
			$table->string('SuspectedDiagnosis', 500)->nullable();
			$table->boolean('HaemPriorityUrgent')->nullable();
			$table->boolean('HaemPriorityRoutine')->nullable();
			$table->boolean('HaemInfoEdtaBlood')->nullable();
			$table->boolean('HaemInfoClottedBlood')->nullable();
			$table->boolean('HaemInfoCitratedBlood')->nullable();
			$table->boolean('HaemInfoFingerPrick')->nullable();
			$table->boolean('RequestHaemaglobin')->nullable();
			$table->boolean('RequestFbcAndDiff')->nullable();
			$table->boolean('RequestBloodFilm')->nullable();
			$table->boolean('RequestBloodGroup')->nullable();
			$table->boolean('RequestRetics')->nullable();
			$table->boolean('RequestESR')->nullable();
			$table->boolean('RequestSickleTest')->nullable();
			$table->boolean('RequestHbGenotype')->nullable();
			$table->boolean('RequestPt')->nullable();
			$table->boolean('RequestAptt')->nullable();
			$table->boolean('RequestInr')->nullable();
			$table->boolean('RequestMalariaMicroscopy')->nullable();
			$table->boolean('RequestMicrofilariaMicroscopy')->nullable();
			$table->boolean('RequestDCT')->nullable();
			$table->boolean('RequestCrossMatchHIV')->nullable();
			$table->boolean('RequestCrossMatchVDRL')->nullable();
			$table->boolean('RequestCrossMatchHepBsAg')->nullable();
			$table->smallInteger('Status')->nullable();
			$table->boolean('Notify')->nullable();
			$table->boolean('NotifyByEmail')->nullable();
			$table->string('EntryPC', 50)->nullable();
			$table->string('EnteredBy', 50)->nullable();
			$table->dateTime('EntryDate')->nullable();
			$table->string('SpecimenCollectedBy', 50)->nullable();
			$table->dateTime('CollectionDate')->nullable();
			$table->time('CollectionTime')->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('LabReqHaematology');
	}

}
