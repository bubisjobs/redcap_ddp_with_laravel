<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTestingGenerateTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('testing_generate', function(Blueprint $table)
		{
			$table->integer('id')->nullable();
			$table->string('firstname', 50)->nullable();
			$table->string('lastname', 50)->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('testing_generate');
	}

}
