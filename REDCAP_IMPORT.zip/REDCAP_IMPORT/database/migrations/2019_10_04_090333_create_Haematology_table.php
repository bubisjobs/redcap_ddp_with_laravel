<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateHaematologyTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('Haematology', function(Blueprint $table)
		{
			$table->integer('requestid')->nullable();
			$table->string('SERIAL', 14);
			$table->string('Diagnosis', 50)->nullable();
			$table->string('ClinicalDiagnosis', 50)->nullable();
			$table->string('StudyNumber', 20)->nullable();
			$table->string('OPDNO', 9);
			$table->string('SCC', 10)->nullable();
			$table->string('PatientName', 50)->nullable();
			$table->smallInteger('Age')->nullable();
			$table->dateTime('DOB')->nullable();
			$table->string('PartialDOB', 20)->nullable();
			$table->char('Sex', 1)->nullable();
			$table->string('Source', 12)->nullable();
			$table->string('ChargeCode', 13)->nullable();
			$table->string('DOCTOR', 15)->nullable();
			$table->char('DoctorSignaturePresent', 1)->nullable();
			$table->smallInteger('Extension')->nullable();
			$table->dateTime('DateOfRequest');
			$table->smallInteger('InfoEdtaBlood')->nullable();
			$table->smallInteger('InfoClottedBlood')->nullable();
			$table->smallInteger('InfoCitratedBlood')->nullable();
			$table->smallInteger('InfoFingerPrick')->nullable();
			$table->smallInteger('InfoSkinSnip')->nullable();
			$table->string('SpecimenCollectedBy', 15)->nullable();
			$table->dateTime('CollectionDate')->nullable();
			$table->char('CollectionTime', 5)->nullable();
			$table->smallInteger('PriorityUrgent')->nullable();
			$table->smallInteger('PriorityRoutine')->nullable();
			$table->smallInteger('RequestHaemaglobin')->nullable();
			$table->smallInteger('RequestFbcAndDiff')->nullable();
			$table->smallInteger('RequestBloodFilm')->nullable();
			$table->smallInteger('RequestBloodGroup')->nullable();
			$table->smallInteger('RequestRetics')->nullable();
			$table->smallInteger('RequestESR')->nullable();
			$table->smallInteger('RequestSickleTest')->nullable();
			$table->smallInteger('RequestHbGenotype')->nullable();
			$table->smallInteger('RequestPt')->nullable();
			$table->smallInteger('RequestAptt')->nullable();
			$table->smallInteger('RequestInr')->nullable();
			$table->smallInteger('RequestVdrl')->nullable();
			$table->string('ReceivedBy', 15)->nullable();
			$table->dateTime('ReceiveDate')->nullable();
			$table->char('ReceiveTime', 5)->nullable();
			$table->float('HB', 53, 0)->nullable();
			$table->float('WBC', 53, 0)->nullable();
			$table->float('NEUTRO', 53, 0)->nullable();
			$table->float('LYMPHO', 53, 0)->nullable();
			$table->float('LymphoMid', 53, 0)->nullable();
			$table->float('MONO', 53, 0)->nullable();
			$table->float('EOS', 53, 0)->nullable();
			$table->float('BASO', 53, 0)->nullable();
			$table->float('RBC', 53, 0)->nullable();
			$table->float('PCV', 53, 0)->nullable();
			$table->float('MCV', 53, 0)->nullable();
			$table->float('MCHC', 53, 0)->nullable();
			$table->string('ThickBloodFilm', 50)->nullable();
			$table->float('PLATS', 53, 0)->nullable();
			$table->string('BLOODGRP', 50)->nullable();
			$table->string('Retics', 50)->nullable();
			$table->float('ESR', 53, 0)->nullable();
			$table->float('RDW', 53, 0)->nullable();
			$table->string('SICKLE', 50)->nullable();
			$table->string('HBGENOT', 50)->nullable();
			$table->float('PT', 53, 0)->nullable();
			$table->float('INR', 53, 0)->nullable();
			$table->float('Aptt', 53, 0)->nullable();
			$table->string('Vdrl', 10)->nullable();
			$table->string('HIVScreen', 3)->nullable();
			$table->string('FilmComment', 1000)->nullable();
			$table->string('LabTechSign', 50)->nullable();
			$table->dateTime('LabTechDate')->nullable();
			$table->string('SupervisorSign', 50)->nullable();
			$table->dateTime('SupervisorSignDate')->nullable();
			$table->string('LabTechCommitSign', 50)->nullable();
			$table->dateTime('LabTechCommitDate')->nullable();
			$table->string('SupervisorCommitSign', 50)->nullable();
			$table->dateTime('SupervisorCommitDate')->nullable();
			$table->string('ClinicianCommitSign', 50)->nullable();
			$table->dateTime('ClinicianCommitDate')->nullable();
			$table->boolean('SupervisorRedo')->nullable();
			$table->boolean('SupervisorCommit')->nullable();
			$table->boolean('ClinicianRedo')->nullable();
			$table->boolean('ClinicianCommit')->nullable();
			$table->string('CompletionStatus', 50)->nullable();
			$table->string('Comments', 200)->nullable();
			$table->string('LabEntryMonth', 3)->nullable();
			$table->smallInteger('LabEntryYear')->nullable();
			$table->string('LabEntryTime', 5)->nullable();
			$table->string('LabOutMonth', 3)->nullable();
			$table->smallInteger('LabOutYear')->nullable();
			$table->dateTime('LabInDate')->nullable();
			$table->time('LabInTime')->nullable();
			$table->dateTime('LabOutDate')->nullable();
			$table->time('LabOutTime')->nullable();
			$table->string('EntryPC', 50)->nullable();
			$table->string('EnteredBy', 50)->nullable();
			$table->dateTime('EntryDate')->nullable();
			$table->float('NeutroAbsolute', 53, 0)->nullable();
			$table->float('LymphoAbsolute', 53, 0)->nullable();
			$table->float('MonoAbsolute', 53, 0)->nullable();
			$table->float('EOSAbsolute', 53, 0)->nullable();
			$table->float('BasoAbsolute', 53, 0)->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('Haematology');
	}

}
