<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateMetaDatasTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('meta_datas', function(Blueprint $table)
		{
			$table->string('field');
			$table->string('label');
			$table->string('description');
			$table->string('temporal');
			$table->string('category');
			$table->string('subcategory');
			$table->string('identifier');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('meta_datas');
	}

}
