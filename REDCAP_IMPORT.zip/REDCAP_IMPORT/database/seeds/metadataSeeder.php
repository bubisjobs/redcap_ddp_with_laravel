<?php

use Illuminate\Database\Seeder;
use App\metaData;

class metadataSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $meta = DB::table('haematologyddp')->insert([
            "field" => "requestid",
            "label" => "RequestID",
           "description" => "Request ID",
           "temporal" => 0,
           "category" => "Demographics",
           "identifier" => "1"
           ]);
    }
}
