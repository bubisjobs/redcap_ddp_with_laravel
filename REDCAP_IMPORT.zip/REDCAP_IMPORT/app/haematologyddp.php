<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class haematologyddp extends Model
{
    //
}
