<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class metaData extends Model
{
    protected $fillable  = ['field', 'label', 'description', 'temporal', 'category', 'identifier'];
    public $timestamps = false;
    //
}
