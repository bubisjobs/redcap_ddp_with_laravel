<?php

namespace App\Http\Controllers;
use App\haematologyddp;
use Illuminate\Support\Collection;
use Illuminate\Http\Request;
use Goutte\Client;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;
  use Symfony\Component\DomCrawler\Crawler;
// use App\Http\Controllers\Auth;
class Haematology extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
    

     */
    public function index(Request $request)
    {
       
      
           if($request->id)
           {
             $theids = $request->id;
      
             $projectid = $request->project_id;
             $haematology = haematologyddp::where('requestid', '=', $theids)->get();
            //  $tables = \DB::select("SELECT * FROM sys.Tables");
                        
                // foreach($tables as $table){
                // $tableNames = $table->name;
                // if($tableNames == 'haematologyddps'){
                //     $tableNames = 'haematologyddps';
                //     }
                // }
             $metas =  \Schema::getColumnListing('haematologyddps');
             echo '[';
          
        
                $array = json_decode($haematology);
              $value = "";
                foreach ($array as $key => $jsons) { // This will search in the 2 jsons
                    foreach($jsons as $key => $value) {
                        foreach($metas as $meta){
           
            
                            $field = ' "field" '. '= '. $meta.',';
                            $vri = ' "value" ' .'= '. $value ; 
                       //   echo $vri;
                           echo '{'. $field, $vri .'},';
                    
                         }
                          // echo $meta;
                         
                   }
                  
               }
            
            //    echo $field;
             
             
                echo ']';
             foreach($haematology as $haema ){
                //    echo $haema;
                                $bubis =  [
                                'field' => $metas[0],
                                'value' => $haema['requestid']
                                ];
                                $project =  [
                                'field' => $metas[1],
                                'value' => $haema['serial']
                                ];
                                $project1 =  [
                                'field' => $metas[3],
                                'value' => $haema['projectid'],
                              
                                ];

                                $diagnosis =  [
                                'field' => $metas[2],
                                'value' => $haema['diagnosis']
                                ];
                                $doctor =  [
                                'field' => $metas[4],
                                'value' => $haema['doctor']
                                ];
                                $date =  [
                                'field' => $metas[5],
                                'value' => $haema['dateofrequest']
                                ];
                                $collected =  [
                                'field' => $metas[6],
                                'value' => $haema['specimencollectedby']
                                ];     
                                $collecteddate =  [
                                'field' => $metas[7],
                                'value' => $haema['collectiondate']
                                ];    
                                $collectedtime =  [
                                'field' => $metas[8],
                                'value' => $haema['collectiontime']
                                ];  
                                $hb =  [
                                'field' => $metas[9],
                                'value' => $haema['hb']
                                ]; 

                                $wbc =  [
                                'field' => $metas[10],
                                'value' => $haema['wbc']
                                ]; 
                                $neutro =  [
                                'field' => $metas[11],
                                'value' => $haema['neutro']
                                ]; 
                                $lympho =  [
                                'field' => $metas[12],
                                'value' => $haema['lympho']
                                ]; 

                                $mono =  [
                                'field' => $metas[13],
                                'value' => $haema['mono']
                                ]; 
                                $eos =  [
                                'field' => $metas[14],
                                'value' => $haema['eos']
                                ];  
                                $baso =  [
                                'field' => $metas[15],
                                'value' => $haema['eos']
                                ]; 
                                $rbc =  [
                                'field' => $metas[16],
                                'value' => $haema['rbc']
                                ]; 
                                $pcv =  [
                                'field' => $metas[17],
                                'value' => $haema['pcv']
                                ]; 
                                $mvc =  [
                                'field' => $metas[18],
                                'value' => $haema['mvc']
                                ]; 
                                $mchc =  [
                                'field' => $metas[19],
                                'value' => $haema['mchc']
                                ]; 
                                $thick =  [
                                'field' => $metas[20],
                                'value' => $haema['thickbloodfilm']
                                ];
                                $plats =  [
                                'field' => $metas[21],
                                'value' => $haema['plats']
                                ];
                                $blood =  [
                                'field' => $metas[22],
                                'value' => $haema['bloodgrp']
                                ];
                                $retics =  [
                                'field' => $metas[23],
                                'value' => $haema['retics']
                                ];
                                $neutroabsolute =  [
                                'field' => $metas[24],
                                'value' => $haema['neutroabsolute']
                                ];
                                $lymphoabsolute =  [
                                'field' => $metas[25],
                                'value' => $haema['lymphoabsolute']
                                ];
                                $monoabsolute =  [
                                'field' => $metas[26],
                                'value' => $haema['monoabsolute']
                                ];
                                $eso =  [
                                'field' => $metas[27],
                                'value' => $haema['esoabsolute']
                                ];
                                $baso =  [
                                'field' => $metas[28],
                                'value' => $haema['basoabsolute']
                                ];
                                $esr =  [
                                'field' => $metas[29],
                                'value' => $haema['esr']
                                ];
                                $rdw =  [
                                'field' => $metas[30],
                                'value' => $haema['rdw']
                                ];
                                $sickle =  [
                                'field' => $metas[31],
                                'value' => $haema['sickle']
                                ];
                                $hbgenot =  [
                                'field' => $metas[32],
                                'value' => $haema['hbgenot']
                                ];
                                $pt =  [
                                'field' => $metas[33],
                                'value' => $haema['pt']
                                ];
                                $inr =  [
                                'field' => $metas[34],
                                'value' => $haema['inr']
                                ];
                                $aptt =  [
                                'field' => $metas[35],
                                'value' => $haema['aptt']
                                ];
                                $filmcomment =  [
                                'field' => $metas[36],
                                'value' => $haema['filmcomment']
                                ];
                                $comments =  [
                                'field' => $metas[37],
                                'value' => $haema['comments']
                                ];
                            }
                        // }                                                                                                                   
//   return [$bubis,  $project1, $project, $diagnosis, $doctor, $date, $collected, $collecteddate, $collectedtime, $hb, $wbc, $neutro, $lympho, $mono, $eos, $baso, $rbc, $pcv, $mvc, $mchc, $thick, $plats, $blood, $retics, $neutroabsolute, $lymphoabsolute, $monoabsolute ,$eso, $baso, $esr, $rdw, $sickle, $hbgenot, $pt, $inr, $aptt, $filmcomment, $comments];                
                  
        //  }
      }else {
          echo "opps nothing found or sent";
      }
     
      
      
    
     
          
     
      
        
       
        

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // header("refresh: 120; url = http://localhost:400/REDCAP_IMPORT/public/datas"); 
        $datas = haematologyddp::all();
        return $datas;
      
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
    }
}
