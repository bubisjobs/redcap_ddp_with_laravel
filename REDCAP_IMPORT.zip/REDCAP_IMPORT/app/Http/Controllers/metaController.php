<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Collection;
use Illuminate\Http\Request;
use App\metaData;
use App\haematologyddp;
use App\customer;
use App\order;
use App\patient;
use App\student;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Schema;

class metaController extends Controller
{
    

    public function getValuesFromTable(){
           
       $tables = \DB::select("SELECT name FROM sys.Tables");
       // print_r($tables);
       foreach($tables as $table => $key){
    
       foreach($key as $keys){
           if($keys == 'customers'){
              echo $keys;
           }
           
    
       }

          
              
           
       

  

}
    
       $metas =  \Schema::getColumnListing($keys);
        echo "[";
           
        foreach($metas as $meta){
           
           $checkForRequestid = $meta;
           $attributes = $meta;
           if ($checkForRequestid == 'requestid'){
                  $identifier  = 1;
           }else {
                  $identifier = 0;
           }

    $values = 
           [
           "field" =>   $attributes,
           "label" => $attributes,
           "identifier" => $identifier,
           "temporal" => 0, 
           "category" => "Demographics",
           "description" => $attributes
           ];
    

        
     
        $all = json_encode($values, true);
            
        
        echo   $all.',';
        
         
       
   

        }
        
        echo $all;
        
        echo ']';
    }

}
