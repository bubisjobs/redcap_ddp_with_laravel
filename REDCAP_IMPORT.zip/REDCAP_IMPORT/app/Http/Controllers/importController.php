<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\haematologyddp;

class importController extends Controller
{
    public function importAllValues()
    {

    
    
    // header("refresh: 120; url = http://localhost:400/REDCAP_IMPORT/public/massImport"); 
        $json_string = "http://localhost:8000/datas";
        
        $datas = file_get_contents($json_string);
      

              $GLOBALS['super_api_token'] = 'ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234';
              $GLOBALS['api_token']       = 'C9ABEEB803EBDA146C7EE74B2465BC00';
              $GLOBALS['api_url']         = 'https://redcap.mrc.gm:8443/redcaptest/api/';
        
              $fields = array(
                'token'   => $GLOBALS['api_token'],
                'content' => 'record',
                'format'  => 'json',
                'type'    => 'flat',
                'data'    => $datas
            );
            
            $ch = curl_init();
            
            curl_setopt($ch, CURLOPT_URL, $GLOBALS['api_url']);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields, '', '&'));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); // Set to TRUE for production use
            curl_setopt($ch, CURLOPT_VERBOSE, 0);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_AUTOREFERER, true);
            curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_FRESH_CONNECT, 1);
            
            $output = curl_exec($ch);
            print $output;
            curl_close($ch);
      

    
    }
}
